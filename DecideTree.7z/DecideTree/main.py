import csv
from sklearn.feature_extraction import DictVectorizer
from sklearn import preprocessing
from sklearn import tree

# 打开一个文本文件读取，文件名采用原始字符串,模式为rt
data = open('data.csv', 'rt')
reader = csv.reader(data)

headers = next(reader)
print(headers)

feature_list = []
result_list = []

for row in reader:
    # row[-1] 最后一列
    result_list.append(row[-1])
    # zip对应元组的两个list合并成一个list
    feature_list.append(dict(zip(headers[1:-1], row[1:-1])))
print(result_list)
print(feature_list)

vec = DictVectorizer()

# 按首字母排序
dummyx = vec.fit_transform(feature_list).toarray()
# 最后一列结果列
dummyY = preprocessing.LabelBinarizer().fit_transform(result_list)

print(dummyx)
print(dummyY)
# tree_model=DecisionTreeClassifier(criterion=“gini”,max_depth=3,random_state=0,splitter=“best”)
clf = tree.DecisionTreeClassifier(criterion='entropy', random_state=0)#实例化
clf = clf.fit(dummyx, dummyY)# 训练
print(clf.score(dummyx,dummyY))
print("clf:" + str(clf))

import pydotplus

dot_data = tree.export_graphviz(clf,
                                feature_names=vec.get_feature_names(),
                                filled=True, # 上色
                                rounded=True,# 圆角
                                special_characters=True,
                                out_file=None)
graph = pydotplus.graph_from_dot_data(dot_data)
graph.write_pdf("file.pdf")
